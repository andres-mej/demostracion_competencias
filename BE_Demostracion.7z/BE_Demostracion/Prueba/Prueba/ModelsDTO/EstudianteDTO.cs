﻿using System;
namespace Prueba.ModelsDTO
{
    public class EstudianteDTO
    {
        public string Id { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
    }
}
