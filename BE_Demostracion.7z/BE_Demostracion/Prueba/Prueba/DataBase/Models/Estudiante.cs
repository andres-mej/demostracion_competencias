﻿using System;
namespace Prueba.DataBase.Models
{
    public class Estudiante
    {
        public string Id { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
    }
}
